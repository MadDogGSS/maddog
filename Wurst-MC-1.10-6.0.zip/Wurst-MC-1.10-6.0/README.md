# Wurst MC 1.10
Wurst Client for Minecraft 1.10 - 1.10.2

[![Download Wurst](https://cloud.githubusercontent.com/assets/10100202/24546386/48b5857c-160b-11e7-9ec0-443379bfdb72.png)](https://www.wurstclient.net/download/)

## The All-in-One Solution
Wurst is one of the few hacked clients that are optimized for both Griefing and PVP.

### Nuker
- Works in Survival and Creative Mode.
- Bypasses NoCheat+.
- Supports ID-based block selection.
- Near-instant speed on vanilla servers.
- Works with FastBreak.

### Killaura
- Bypasses NoCheat+, AntiAura and Mineplex.
- Supports target selection by team color.
- Up to 20 attacks per second.
- Supports MultiAura, TP-Aura and ClickAura.
- Works with attack cooldown.

### Other Griefing Features
ServerFinder, BaseFinder, AuthMe Cracker, OP-Sign, BookHack, AutoBuild, BuildRandom, FastBreak, X-Ray, AutoMine, AutoSign

### Other PVP Features
AutoArmor, ScaffoldWalk, AutoSoup, AutoSplashPot, FightBot, BowAimbot, Tracers, FastBow, Blink, Criticals, AutoSteal

## It doesn't end there!
Wurst has hundreds of features and we keep adding more. For a complete-ish list of features, see [Feature List](https://www.wurstclient.net/features/).

## Live Downloads Counter
![downloads counter](https://drive.google.com/uc?id=0B2YeSS9tm5zLMF9NWjNZYnNqSTA)

Copyright © 2014 - 2017 | Wurst-Imperium | All rights reserved.
